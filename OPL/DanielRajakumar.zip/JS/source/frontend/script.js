/**
 * Game UI elements and state management for a board game application.
 * This script handles all frontend interactions with the game backend.
 * 
 * The game involves two players taking turns to cover/uncover squares based on dice rolls.
 * Players can be human or computer-controlled.
 */

// DOM Element References
// These elements represent the different parts of the game interface
const initialUI = document.getElementById("initial-ui");        // Initial screen (start menu)
const regularUI = document.getElementById("regular-ui");        // Main game screen
const loadGameInitialButton = document.getElementById("load-game-initial"); // Load game button
const newGameInitialButton = document.getElementById("new-game-initial");   // New game button
const humanSquaresElement = document.getElementById("human-squares");      // Player 1's board
const computerSquaresElement = document.getElementById("computer-squares"); // Player 2's board
const humanScoreElement = document.getElementById("human-score");           // Player 1 score display
const computerScoreElement = document.getElementById("computer-score");     // Player 2 score display
const diceRollElement = document.getElementById("dice-roll");              // Dice roll result display
const gameMessageElement = document.getElementById("game-message");        // Game status messages
const rollDiceButton = document.getElementById("roll-dice");              // Roll dice button
const helpButton = document.getElementById("help");                        // Help button
const rewindButton = document.getElementById("rewind");                    // Rewind move button
const saveGameButton = document.getElementById("save-game");               // Save game button
const boardSizeSelect = document.getElementById("board-size");             // Board size selector
const applyConfigButton = document.getElementById("apply-config");         // Apply settings button
const preGameElement = document.getElementById("pre-game");                // Pre-game config screen
const liveGameElement = document.getElementById("live-game");              // Main game screen
const inputDiceButton = document.getElementById("input-dice");             // Manual dice input button
const diceModalElement = document.getElementById("dice-modal");            // Dice input modal
const gameUIElement = document.getElementById("game-ui");                  // Main game container
const diceResultElement = document.getElementById("dice-result");          // Dice result display
const submitDiceButton = document.getElementById("submit-dice");           // Submit manual dice button
const closeButton = document.getElementById("close-button");               // Close modal button
const validRollsElement = document.getElementById("valid-rolls");          // Valid moves dropdown
const confirmValidRollsButton = document.getElementById("confirm-valid-rolls"); // Confirm move button
const coverSwitchElement = document.getElementById("cover-switch");        // Cover/uncover toggle
const fileInput = document.getElementById("file-input");                   // File upload input
const computerBoardElement = document.getElementById("computer-board");     // Computer's board container
const humanBoardElement = document.getElementById("human-board");          // Human's board container
const player1TypeElement = document.getElementById("player1-type-select"); // Player 1 type selector
const player2TypeElement = document.getElementById("player2-type-select"); // Player 2 type selector
const toggleSwitchElement = document.getElementById("toggle-switch");      // Board view toggle
const ExitGameButton = document.getElementById("exit-game");               // Exit game button
const playAgainGameButton = document.getElementById("play-again-game");    // Play again button
const roundWinnerElement = document.getElementById("round-winner");        // Round winner display
const roundWinnerTextElement = document.getElementById("round-winner-text"); // Winner text
const currentTurnElement = document.querySelector("#live-game > div.current-turn"); // Turn indicator
const rewindModalElement = document.getElementById("rewind-modal");        // Rewind history modal
const closeRewindButton = document.getElementById("close-rewind-button");  // Close rewind modal button
const confirmRewindButton = document.getElementById("confirm-rewind");     // Confirm rewind button
const historyListElement = document.getElementById("history-list");        // Move history list
const useOneDieElement = document.getElementById("use-one-die");           // Use one die checkbox
const diceToggleContainer = document.getElementById("dice-toggle-container"); // Dice options container
const titleElement = document.getElementById("title-game");                // Game title
const rollDieFirstPlayerElement = document.getElementById("roll-die-first-player"); // First roll button
const gameBoardElement = document.getElementById("game-board");            // Game board container
const playButton = document.getElementById("play-button");                 // Start game button

// Game state variables
let selectedHistoryIndex = -1;  // Track selected move in rewind history
let isNewGame = true;           // Flag for new game vs resumed game

// Event Listeners
loadGameInitialButton.addEventListener("click", handleLoadGame);
newGameInitialButton.addEventListener("click", handleNewGame);
rollDiceButton.addEventListener("click", handleRollDice);
helpButton.addEventListener("click", handleHelp);
rewindButton.addEventListener("click", showRewindModal);
saveGameButton.addEventListener("click", handleSaveGame);
applyConfigButton.addEventListener("click", handleApplyConfig);
rollDieFirstPlayerElement.addEventListener("click", handleFirstTurnRoll);
playButton.addEventListener("click", handleStartGame);
inputDiceButton.addEventListener("click", handleInputDice);
closeButton.addEventListener("click", closeDiceModal);
submitDiceButton.addEventListener("click", handleSubmitDice);
confirmValidRollsButton.addEventListener("click", handleConfirmValidRolls);
fileInput.addEventListener("change", handleFileUpload);
toggleSwitchElement.addEventListener("change", handleToggleSwitch);
ExitGameButton.addEventListener("click", handleExitGame);
playAgainGameButton.addEventListener("click", handlePlayAgain);
confirmRewindButton.addEventListener("click", handleConfirmRewind);
closeRewindButton.addEventListener("click", closeRewindModal);
useOneDieElement.addEventListener("change", handleUseOneDieChange);

/**
 * Shows the regular game UI by hiding the initial UI
 * Used when transitioning from start screen to main game
 */
function showRegularUI() {
  initialUI.classList.add("hidden");
  regularUI.classList.remove("hidden");
}

/**
 * Renders squares for a player's board with visual indicators
 * 
 * Handles:
 * - Displaying covered/uncovered squares
 * - Highlighting the advantage square
 * - Showing protection on opponent's advantage square when applicable
 * 
 * @param {HTMLElement} container - DOM element to render into 
 * @param {Array<number>} squares - Current square states (0 = covered)
 * @param {number} advantage - Position of advantage square (1-based) or -1 if none
 */
function renderSquares(container, squares, advantage) {
  container.innerHTML = "";
  const squaresWrapper = document.createElement("div");
  squaresWrapper.classList.add("squares-wrapper");

  // Visual representation as an array: [1 2 3...]
  const openBracket = document.createElement("span");
  openBracket.textContent = "[";
  openBracket.classList.add("square-num");
  squaresWrapper.appendChild(openBracket);

  squares.forEach((square, index) => {
    const squareElement = document.createElement("span");
    squareElement.classList.add("square");
    const position = index + 1;  // Convert to 1-based index
       
    // Check if this is a protected advantage square (on opponent's board)
    const isProtected = position === advantage && 
                       container.id === "computer-squares" && 
                       !canUncoverAdvantageSquare();

    if (isProtected) {
      // Show protected state - can't be uncovered yet
      squareElement.classList.add("protected-advantage");
      squareElement.title = "Cannot uncover until advantaged player takes a turn";
    } else if (position === advantage) {
      // Normal advantage square highlighting
      squareElement.classList.add("advantage");
    }

    squareElement.textContent = square;
    squareElement.classList.add("square-num");
    squaresWrapper.appendChild(squareElement);

    // Add space between numbers but not after last one
    if (index !== squares.length - 1) {
      const comma = document.createElement("span");
      comma.textContent = " ";
      squaresWrapper.appendChild(comma);
    }
  });

  // Close the visual array representation
  const closeBracket = document.createElement("span");
  closeBracket.classList.add("square-num");
  closeBracket.textContent = "]";
  squaresWrapper.appendChild(closeBracket);

  container.appendChild(squaresWrapper);
}

/**
 * Fetches the current game state from the backend
 * @returns {Promise<Object>} The game state object containing:
 * - Player boards
 * - Scores
 * - Current turn
 * - Advantage status
 */
async function fetchGameState() {
  try {
    const response = await fetch("http://localhost:3000/api/game/state");
    if (!response.ok) throw new Error("Failed to fetch game state");
    const data = await response.json();
    console.log("Game state from backend:", data); 
    return data;
  } catch (error) {
    console.error("Error fetching game state:", error);
    gameMessageElement.textContent = "Error loading game state";
    return null;
  }
}

/**
 * Updates all UI elements with current game state
 * 
 * This is the main function that keeps the interface in sync
 * with the backend game state
 */
async function updateUI() {
  try {
    const state = await fetchGameState();
    if (!state) return;

    // Update player boards with advantage indicators
    if (state.advantage.player === "player1") {
      renderSquares(humanSquaresElement, state.player1.squares, state.advantage.square);
    } else {
      renderSquares(humanSquaresElement, state.player1.squares, -1);
    }

    if (state.advantage.player === "player2") {
      renderSquares(computerSquaresElement, state.player2.squares, state.advantage.square);
    } else {
      renderSquares(computerSquaresElement, state.player2.squares, -1);
    }

    // Update scores and game info
    humanScoreElement.textContent = state.player1.score;
    computerScoreElement.textContent = state.player2.score;
    diceRollElement.textContent = state.diceRoll || "No dice rolled yet.";
    gameMessageElement.textContent = state.message || "";
    currentTurnElement.textContent = "Current Turn: " + (state.currentPlayer || "Unknown");
    diceResultElement.textContent = "Dice: " + (state.dice?.total || "No dice rolled yet.");
    
    // Update player type displays
    document.querySelector("#human-board > h2").innerHTML = "Player 1: " + state.player1.type;
    document.querySelector("#computer-board > h2").innerHTML = "Player 2: " + state.player2.type;
  } catch (error) {
    console.error("Error updating UI:", error);
    gameMessageElement.textContent = "Error updating game display";
  }
}

/**
 * Handles loading a saved game from server storage
 */
async function handleLoadGame() {
  try {
    gameMessageElement.textContent = "Loading game...";
    const response = await fetch("http://localhost:3000/api/game/load", {
      method: "POST",
    });
    
    if (!response.ok) throw new Error("Load request failed");
    
    const data = await response.json();
    console.log("Load game response:", data); 

    if (data.screen === "LOAD") {
      showConfigUI(data.screen);
    } else {
      console.error("Unknown screen:", data.screen);
      gameMessageElement.textContent = "Unexpected response from server";
    }
  } catch (error) {
    console.error("Error loading game:", error);
    gameMessageElement.textContent = "Failed to load game";
  }
}

/**
 * Handles starting a new game by showing configuration UI
 */
async function handleNewGame() {
  try {
    isNewGame = true;
    showConfigUI("CONFIG");
    gameMessageElement.textContent = "Configure your new game";
  } catch (error) {
    console.error("Error starting new game:", error);
    gameMessageElement.textContent = "Error setting up new game";
  }
}

/**
 * Handles the dice roll action
 * 
 * This initiates a new turn by:
 * 1. Sending roll request to backend
 * 2. Processing the result
 * 3. Updating UI based on who rolled (human/computer)
 */
async function handleRollDice() {
  try {
    gameMessageElement.textContent = "Rolling dice...";
    rollDiceButton.disabled = true;
    
    const response = await fetch("http://localhost:3000/api/game/roll-dice", {
      method: "POST",
    });
    
    if (!response.ok) throw new Error("Roll request failed");
    
    const data = await response.json();
    console.log("Roll dice response:", data);
    afterDieRoll(data);  // Process the roll result
  } catch (error) {
    console.error("Failed to roll dice:", error);
    gameMessageElement.textContent = "Error rolling dice. Please try again.";
  } finally {
    rollDiceButton.disabled = false;
  }
}

/**
 * Handles requesting help from the computer
 * Shows suggested moves for human players
 */
async function handleHelp() {
  try {
    gameMessageElement.textContent = "Getting help...";
    helpButton.disabled = true;
    
    const response = await fetch("http://localhost:3000/api/game/help", {
      method: "POST",
    });
    
    if (!response.ok) throw new Error("Help request failed");
    
    const data = await response.json();
    console.log("Help response:", data);
    updateUI();
    gameMessageElement.textContent = data.message || "Here's a suggested move";
  } catch (error) {
    console.error("Error getting help:", error);
    gameMessageElement.textContent = "Failed to get help";
  } finally {
    helpButton.disabled = false;
  }
}

/**
 * Handles saving the current game state to server storage
 */
async function handleSaveGame() {
  try {
    gameMessageElement.textContent = "Saving game...";
    saveGameButton.disabled = true;
    
    const response = await fetch("http://localhost:3000/api/game/save", {
      method: "POST",
    });
    
    if (!response.ok) throw new Error("Save request failed");
    
    const data = await response.json();
    console.log("Save game response:", data); 
    saveGame();  // Handle file save to local system
    gameMessageElement.textContent = "Game saved successfully!";
  } catch (error) {
    console.error("Error saving game:", error);
    gameMessageElement.textContent = "Failed to save game";
  } finally {
    saveGameButton.disabled = false;
  }
}

/**
 * Handles applying game configuration settings
 * 
 * Sends board size and player types to backend
 * to initialize a new game
 */
async function handleApplyConfig() {
  try {
    gameMessageElement.textContent = "Applying settings...";
    applyConfigButton.disabled = true;
    
    const boardSize = boardSizeSelect.value;
    const player1Type = player1TypeElement.value;
    const player2Type = player2TypeElement.value;

    const endpoint = isNewGame ? "new" : "play-again";
    const response = await fetch(`http://localhost:3000/api/game/${endpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ boardSize, player1Type, player2Type }),
    });
    
    if (!response.ok) throw new Error("Config request failed");
    
    const data = await response.json();
    console.log("Apply config response:", data); 

    if (data.screen === "PLAY") {
      // Transition to game screen
      preGameElement.classList.add("hidden");
      liveGameElement.classList.remove("hidden");
      rollDieFirstPlayerElement.classList.remove("hidden");
      
      // Set up initial UI state
      rollDiceButton.classList.add("hidden");
      helpButton.classList.add("hidden");
      coverSwitchElement.classList.add("hidden");
      ExitGameButton.classList.add("hidden");
      playAgainGameButton.classList.add("hidden");
      currentTurnElement.classList.add("hidden");
      inputDiceButton.classList.add("hidden");
      rewindButton.classList.add("hidden");
      saveGameButton.classList.add("hidden");  
      gameBoardElement.classList.add("hidden");
      gameMessageElement.classList.remove("hidden");
      playButton.classList.add("hidden");
      
      gameMessageElement.textContent = "Game ready! Roll to determine first turn";
    } else {
      console.error("Unknown screen:", data.screen);
      gameMessageElement.textContent = "Unexpected response from server";
    }
  } catch (error) {
    console.error("Error applying config:", error);
    gameMessageElement.textContent = "Failed to apply settings";
  } finally {
    applyConfigButton.disabled = false;
  }
}

/**
 * Handles rolling for first turn determination
 * 
 * Both players roll a die, higher roll goes first
 * Handles tie cases by prompting to roll again
 */
async function handleFirstTurnRoll() {
  try {
    gameMessageElement.textContent = "Determining first turn...";
    rollDieFirstPlayerElement.disabled = true;
    
    const response = await fetch("http://localhost:3000/api/game/roll-dice-first-turn", {
      method: "POST",
    });

    if (!response.ok) throw new Error("First roll request failed");
    
    const data = await response.json();
    let msg = "";

    // Handle different roll outcomes
    if (data.winner === "tie") {
      msg = `You rolled ${data.p1} & Computer rolled ${data.p2}. It's a tie! Please roll again.`;
    } else if (data.winner === "player1") {
      msg = `You rolled ${data.p1} & Computer rolled ${data.p2}. You win the first turn!`;
    } else if (data.winner === "player2") {
      msg = `You rolled ${data.p1} | Computer rolled ${data.p2}. Computer wins the first turn!`;
    }

    gameMessageElement.textContent = msg;
    rollDieFirstPlayerElement.classList.add("hidden");
    
    // Only show play button if not a tie
    if (data.winner !== "tie") {
      playButton.classList.remove("hidden");
    }
  } catch (error) {
    console.error("Error determining first turn:", error);
    gameMessageElement.textContent = "Error determining first turn";
  } finally {
    rollDieFirstPlayerElement.disabled = false;
  }
}

/**
 * Handles starting the game after first turn is determined
 * 
 * Transitions from first roll screen to main game interface
 */
async function handleStartGame() {
  try {
    gameMessageElement.textContent = "Starting game...";
    playButton.disabled = true;
    
    const response = await fetch("http://localhost:3000/api/game/start-game", {
      method: "POST",
    });

    if (!response.ok) throw new Error("Start game request failed");
    
    showLiveGameUI();
    updateUI();

    // Set up UI for active game
    liveGameElement.classList.remove("hidden");
    rollDiceButton.classList.remove("hidden");
    helpButton.classList.add("hidden");
    coverSwitchElement.classList.add("hidden");
    ExitGameButton.classList.add("hidden");
    playAgainGameButton.classList.add("hidden");
    currentTurnElement.classList.remove("hidden");
    inputDiceButton.classList.remove("hidden");
    rewindButton.classList.remove("hidden");
    saveGameButton.classList.remove("hidden");  
    gameBoardElement.classList.remove("hidden");
    playButton.classList.add("hidden");
    
    gameMessageElement.textContent = "Game started!";
  } catch (error) {
    console.error("Error starting game:", error);
    gameMessageElement.textContent = "Failed to start game";
  } finally {
    playButton.disabled = false;
  }
}

/**
 * Handles opening the manual dice input modal
 * 
 * Checks if single die mode is allowed before showing options
 */
async function handleInputDice() {
  try {
    const canThrowSingleDie = await canThrowOneDie();

    if (canThrowSingleDie) {
      diceToggleContainer.classList.remove("hidden");
    }

    regularUI.classList.add("hidden");
    diceModalElement.classList.remove("hidden");
    gameMessageElement.textContent = "Enter your dice values";
  } catch (error) {
    console.error("Error opening dice input:", error);
    gameMessageElement.textContent = "Error setting up dice input";
  }
}

/**
 * Closes the dice input modal
 */
function closeDiceModal() {
  regularUI.classList.remove("hidden");
  diceModalElement.classList.add("hidden");
  gameMessageElement.textContent = "";
}

/**
 * Handles submitting manually entered dice values
 * 
 * Validates input before sending to backend
 */
async function handleSubmitDice() {
  try {
    const dice1 = parseInt(document.getElementById("dice1").value);
    const dice2 = parseInt(document.getElementById("dice2").value);
    const inputDice = [dice1, dice2];
    const useOneDie = useOneDieElement.checked;

    // Validate input
    if (!useOneDie && (isNaN(dice1) || isNaN(dice2) || dice1 < 1 || dice1 > 6 || dice2 < 1 || dice2 > 6)) {
      alert("Please enter valid dice values between 1 and 6");
      return;
    }

    gameMessageElement.textContent = "Processing dice...";
    submitDiceButton.disabled = true;
    
    const response = await fetch("http://localhost:3000/api/game/roll-dice", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ inputDice }),
    });

    if (!response.ok) throw new Error("Dice submission failed");
    
    const data = await response.json();
    console.log("Input dice response:", data); 
    afterDieRoll(data);
    gameMessageElement.textContent = "Dice accepted!";
  } catch (error) {
    console.error("Error submitting dice:", error);
    gameMessageElement.textContent = "Failed to process dice";
  } finally {
    submitDiceButton.disabled = false;
  }
}

/**
 * Handles confirming selected valid moves
 * 
 * Sends the player's move choice to backend
 */
async function handleConfirmValidRolls() {
  try {
    const validMove = validRollsElement.value;
    const toCover = toggleSwitchElement.checked;
    
    gameMessageElement.textContent = "Processing move...";
    confirmValidRollsButton.disabled = true;
    
    await validRolls(validMove, toCover);
    gameMessageElement.textContent = "Move processed!";
  } catch (error) {
    console.error("Error confirming move:", error);
    gameMessageElement.textContent = "Failed to process move";
  } finally {
    confirmValidRollsButton.disabled = false;
  }
}

/**
 * Handles uploading a saved game file
 * 
 * Parses the file and sends to backend to load game state
 * @param {Event} event - The file input change event
 */
async function handleFileUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  try {
    gameMessageElement.textContent = "Loading game file...";
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const content = e.target.result;
        const gameState = parseGameState(content);
        gameState.player1Type = "human";
        gameState.player2Type = "computer";

        const response = await fetch("http://localhost:3000/api/game/load-file", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(gameState),
        });

        if (!response.ok) throw new Error("File load request failed");
        
        const data = await response.json();
        console.log("File load response:", data);

        showLiveGameUI();
        updateUI();

        // Set up UI for loaded game
        rollDiceButton.classList.remove("hidden");
        helpButton.classList.add("hidden");
        coverSwitchElement.classList.add("hidden");
        ExitGameButton.classList.add("hidden");
        playAgainGameButton.classList.add("hidden");
        currentTurnElement.classList.remove("hidden");
        fileInput.classList.add("hidden");
        rollDieFirstPlayerElement.classList.add("hidden");
        playButton.classList.add("hidden");
        
        gameMessageElement.textContent = "Game loaded successfully!";
      } catch (parseError) {
        console.error("Error parsing or loading game state:", parseError);
        gameMessageElement.textContent = "Invalid game file format";
      }
    };
    
    reader.readAsText(file);
  } catch (error) {
    console.error("Error handling file upload:", error);
    gameMessageElement.textContent = "Failed to load game file";
  }
}

/**
 * Handles toggle switch changes between cover/uncover modes
 */
async function handleToggleSwitch() {
  try {
    const checked = toggleSwitchElement.checked;
    gameMessageElement.textContent = "Updating mode...";
    toggleSwitchElement.disabled = true;
    
    const response = await fetch("http://localhost:3000/api/game/toggle", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ checked }),
    });
    
    if (!response.ok) throw new Error("Toggle request failed");
    
    const data = await response.json();
    console.log("Toggle response:", data); 
    populateStringSelect(data);
    updateUI();
    gameMessageElement.textContent = checked ? "Now in cover mode" : "Now in uncover mode";
  } catch (error) {
    console.error("Error toggling mode:", error);
    gameMessageElement.textContent = "Failed to change mode";
  } finally {
    toggleSwitchElement.disabled = false;
  }
}

/**
 * Handles exiting the game and showing winner
 */
async function handleExitGame() {
  try {
    gameMessageElement.textContent = "Finalizing game...";
    ExitGameButton.disabled = true;
    
    const response = await fetch("http://localhost:3000/api/game/winner", {
      method: "POST",
    });
    
    if (!response.ok) throw new Error("Exit request failed");
    
    const data = await response.json();
    console.log("Exit game response:", data);
    showStartUI();
    loadGameInitialButton.classList.add("hidden");
    newGameInitialButton.classList.add("hidden");
    titleElement.textContent = "Winner is: " + data.winner;
  } catch (error) {
    console.error("Error exiting game:", error);
    gameMessageElement.textContent = "Failed to exit game";
  } finally {
    ExitGameButton.disabled = false;
  }
}

/**
 * Handles playing the game again with same settings
 * 
 * Preserves previous game configuration
 */
async function handlePlayAgain() {
  try {
    console.log("Playing again");
    player1TypeElement.disabled = true;
    player2TypeElement.disabled = true;
    isNewGame = false;

    // Get previous state to maintain settings
    const previousState = await fetchGameState();
    console.log("Previous state:", previousState);

    if (previousState) {
      boardSizeSelect.value = previousState.BOARD_SIZE;
      player1TypeElement.value = previousState.fullGame.player1.type;
      player2TypeElement.value = previousState.fullGame.player2.type;
    }
    
    showConfigUI("CONFIG");
    gameMessageElement.textContent = "Setting up new game with same settings...";
  } catch (error) {
    console.error("Error setting up play again:", error);
    gameMessageElement.textContent = "Failed to set up new game";
  }
}

/**
 * Handles confirming rewind to selected move
 */
async function handleConfirmRewind() {
  try {
    const selectedItem = document.querySelector(".move-item.selected");
    if (!selectedItem) {
      alert("Please select a move to rewind to");
      return;
    }

    gameMessageElement.textContent = "Rewinding move...";
    confirmRewindButton.disabled = true;
    
    const index = parseInt(selectedItem.dataset.index);
    const response = await fetch("http://localhost:3000/api/game/rewind-move", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ index }),
    });
    
    if (!response.ok) throw new Error("Rewind request failed");
    
    const data = await response.json();
    updateUI();
    rewindModalElement.classList.add("hidden");
    regularUI.classList.remove("hidden");
    gameMessageElement.textContent = "Game rewound to selected move";
  } catch (error) {
    console.error("Error rewinding move:", error);
    gameMessageElement.textContent = "Failed to rewind move";
  } finally {
    confirmRewindButton.disabled = false;
  }
}

/**
 * Closes the rewind history modal
 */
function closeRewindModal() {
  rewindModalElement.classList.add("hidden");
  regularUI.classList.remove("hidden");
}

/**
 * Handles changes to the "use one die" checkbox
 * 
 * Disables/enables the second die input accordingly
 */
function handleUseOneDieChange() {
  const dice2Input = document.getElementById("dice2");
  
  if (useOneDieElement.checked) {
    dice2Input.disabled = true;
    dice2Input.value = 0;
  } else {
    dice2Input.disabled = false;
  }
}

/**
 * Processes valid rolls selection
 * 
 * Sends the selected move to backend for validation and processing
 * @param {string} validMove - The selected valid move
 * @param {boolean} toCover - Whether to cover or uncover squares
 */
async function validRolls(validMove = validRollsElement.value, toCover = toggleSwitchElement.checked) {
  try {
    console.log("Processing move:", validMove, toCover ? "cover" : "uncover");
    
    const response = await fetch("http://localhost:3000/api/game/valid-move", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ validMove, toCover }),
    });

    if (!response.ok) throw new Error("Move validation failed");
    
    const data = await response.json();
    console.log("Move response:", data); 
    afterValidRoll(data);
    updateUI();
  } catch (error) {
    console.error("Error processing move:", error);
    gameMessageElement.textContent = "Failed to process move";
  }
}

/**
 * Updates UI after valid rolls are processed
 * 
 * Handles transition between move phases and game over state
 * @param {Object} data - Game state data after processing valid rolls
 */
function afterValidRoll(data) {
  // Reset UI elements for next turn
  diceResultElement.classList.add("hidden");
  rollDiceButton.classList.remove("hidden");
  inputDiceButton.classList.remove("hidden");
  validRollsElement.classList.add("hidden");
  confirmValidRollsButton.classList.add("hidden");
  coverSwitchElement.classList.add("hidden");
  rewindButton.classList.remove("hidden");
  saveGameButton.classList.remove("hidden");
  helpButton.classList.add("hidden");

  // Handle game over state
  if (data.gameOver) {
    console.log("Game over! Winner:", data.winner);
    
    // Disable game controls
    rewindButton.classList.add("hidden");
    saveGameButton.classList.add("hidden");
    inputDiceButton.classList.add("hidden");
    rollDiceButton.classList.add("hidden");
    
    // Show game over options
    ExitGameButton.classList.remove("hidden");
    playAgainGameButton.classList.remove("hidden");
    helpButton.classList.add("hidden");
    currentTurnElement.classList.add("hidden");
    document.querySelector("#live-game > div.game-board").classList.add("hidden");

    // Highlight winner
    gameUIElement.classList.add("hidden");
    alert(`Game Over! Winner: ${data.winner}`);
    gameUIElement.classList.remove("hidden");
  }
}

/**
 * Shows the start UI screen with game title and options
 */
function showStartUI() {
  initialUI.classList.remove("hidden");
  regularUI.classList.add("hidden");
  gameMessageElement.textContent = "Welcome to the game!";
}

/**
 * Shows the configuration UI screen
 * @param {string} screen - The screen to show ("CONFIG" or "LOAD")
 */
function showConfigUI(screen) {
  if (screen === "CONFIG") {
    // Show new game configuration
    initialUI.classList.add("hidden");
    regularUI.classList.remove("hidden");
    preGameElement.classList.remove("hidden");
    liveGameElement.classList.add("hidden");
    document.querySelector("#live-game > div.game-board").classList.remove("hidden");
    diceResultElement.classList.add("hidden");
    gameMessageElement.textContent = "Configure your game settings";
  } else if (screen === "LOAD") {
    // Show load game interface
    initialUI.classList.add("hidden");
    fileInput.classList.remove("hidden");
    gameMessageElement.textContent = "Select a saved game file";
  }
}

/**
 * Shows the live game UI screen with all game controls
 */
function showLiveGameUI() {
  initialUI.classList.add("hidden");
  regularUI.classList.remove("hidden");
  preGameElement.classList.add("hidden");
  liveGameElement.classList.remove("hidden");
  gameMessageElement.textContent = "Game in progress";
}

/**
 * Processes the game state after dice are rolled
 * 
 * Handles:
 * - Computer moves automatically
 * - Shows valid moves for human players
 * - Updates UI elements accordingly
 * @param {Object} data - Game state from backend after rolling
 */
function afterDieRoll(data) {
  // Computer players make their move immediately
  if ((data.currentPlayer === "player1" && data.player1.type === "computer") ||
      (data.currentPlayer === "player2" && data.player2.type === "computer")) {
    validRolls(data.move.combination, data.move.action === "cover");
  }

  // Show dice result and available moves
  regularUI.classList.remove("hidden");
  diceModalElement.classList.add("hidden");
  diceResultElement.classList.remove("hidden");
  diceResultElement.textContent = `Dice: ${data.dice.total}`;
  
  // Set up UI for player's turn
  rollDiceButton.classList.add("hidden");
  inputDiceButton.classList.add("hidden");
  validRollsElement.classList.remove("hidden");
  confirmValidRollsButton.classList.remove("hidden");
  coverSwitchElement.classList.remove("hidden");
  rewindButton.classList.add("hidden");
  saveGameButton.classList.add("hidden");

  // Populate valid moves dropdown
  populateStringSelect(data.validCoverCombinations || []);

  // Enable help for human players
  if ((data.currentPlayer === "player1" && data.player1.type === "human") ||
      (data.currentPlayer === "player2" && data.player2.type === "human")) {
    helpButton.classList.remove("hidden");
  } else {
    helpButton.classList.add("hidden");
  }

  updateUI();  // Refresh all game displays
}

/**
 * Populates the valid moves dropdown with available options
 * 
 * Filters out invalid moves based on advantage square rules
 * @param {Array<string>} strings - Array of valid move strings
 */
async function populateStringSelect(strings) {
  const validRollsElement = document.getElementById("valid-rolls");
  validRollsElement.innerHTML = "";
  
  // Get current game state for advantage rules
  const state = await fetchGameState();
  const advantageSquare = state.advantage?.square;
  const advantageApplied = state.advantage?.applied;
  const isOpponentBoard = !toggleSwitchElement.checked; 
  const currentPlayer = state.currentPlayer;
  const advantagePlayer = state.advantage?.player;
  
  // Check if advantage square can be uncovered
  const canUncover = advantageApplied ? 
    (currentPlayer === advantagePlayer || state.advantage?.hasTakenTurn) : true;

  // Add each valid move option
  strings.forEach(str => {
    // Skip moves involving protected advantage square
    if (advantageApplied && isOpponentBoard && str.includes(advantageSquare) && !canUncover) {
      return;
    }
    
    const option = document.createElement("option");
    option.value = str;
    option.textContent = str;
    validRollsElement.appendChild(option);
  });
}

/**
 * Saves the current game state to a local file
 * 
 * Creates a text file containing all game state information
 */
async function saveGame() {
  try {
    gameMessageElement.textContent = "Preparing save file...";
    
    // Gather current game state from UI
    const humanSquares = Array.from(humanSquaresElement.querySelectorAll('.square'))
                           .map(square => square.textContent).join(' ');
    const computerSquares = Array.from(computerSquaresElement.querySelectorAll('.square'))
                             .map(square => square.textContent).join(' ');
    const humanScore = humanScoreElement.textContent;
    const computerScore = computerScoreElement.textContent;
    const currentTurn = currentTurnElement.textContent.includes("1") ? "player1" : "player2";

    // Format game state as human-readable text
    const gameStateString = `
Computer:
  Squares: ${computerSquares}
  Score: ${computerScore}

Human:
  Squares: ${humanSquares}
  Score: ${humanScore}

First Turn: ${currentTurn}
Next Turn: ${currentTurn === "player1" ? "player2" : "player1"}`;

    // Create file and prompt user to save
    const blob = new Blob([gameStateString], { type: "text/plain;charset=utf-8" });
    const fileHandle = await window.showSaveFilePicker({
      suggestedName: "savegame.txt",
      types: [{
        description: "Text Files",
        accept: { "text/plain": [".txt"] },
      }],
    });

    // Write file
    const writableStream = await fileHandle.createWritable();
    await writableStream.write(blob);
    await writableStream.close();

    console.log("Game saved successfully!");
    showStartUI();
    gameMessageElement.textContent = "Game saved successfully!";
  } catch (error) {
    console.error("Error saving the game:", error);
    gameMessageElement.textContent = "Failed to save game. Please try again.";
  }
}

/**
 * Parses game state from file content
 * 
 * Extracts:
 * - Player board states
 * - Scores
 * - Turn information
 * @param {string} content - The file content to parse
 * @returns {Object} The parsed game state object
 */
function parseGameState(content) {
  const lines = content.split("\n");
  const gameState = {
    player1: { type: "human", squares: [], score: 0 },
    player2: { type: "computer", squares: [], score: 0 },
    currentPlayer: "player1",
    screen: "PLAY",
    advantage: { square: null, applied: false, player: null }
  };

  // Parse each line of the save file
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (line.includes("Computer:")) {
      // Parse computer player data
      const squaresLine = lines[++i].trim();
      gameState.player2.squares = squaresLine
        .split("Squares:")[1]
        .trim()
        .split(/\s+/) 
        .map(Number);

      const scoreLine = lines[++i].trim();
      gameState.player2.score = parseInt(scoreLine.split("Score:")[1].trim());
    } else if (line.includes("Human:")) {
      // Parse human player data
      const squaresLine = lines[++i].trim();
      gameState.player1.squares = squaresLine
        .split("Squares:")[1]
        .trim()
        .split(/\s+/) 
        .map(Number);

      const scoreLine = lines[++i].trim();
      gameState.player1.score = parseInt(scoreLine.split("Score:")[1].trim());
    } else if (line.includes("First Turn:")) {
      // Parse starting player
      gameState.currentPlayer = line.includes("Human") ? "player1" : "player2";
      gameState.firstTurn = gameState.currentPlayer;
    } else if (line.includes("Next Turn:")) {
      // Parse current player
      gameState.currentPlayer = line.includes("Human") ? "player1" : "player2";
    }
  }

  // Set board size based on parsed squares
  gameState.boardSize = gameState.player1.squares.length || gameState.player2.squares.length;
  console.log("Parsed game state:", gameState);
  return gameState;
}

/**
 * Checks if one die can be thrown according to game rules
 * @returns {Promise<boolean>} Whether one die can be thrown
 */
async function canThrowOneDie() {
  try {
    const response = await fetch('http://localhost:3000/api/game/can-throw-one-die');
    if (response.ok) {
      const data = await response.json();
      return data.canThrowOneDie;
    }
    return false; 
  } catch (error) {
    console.error('Error checking dice rules:', error);
    return false;
  }
}

/**
 * Shows the rewind modal with move history
 */
async function showRewindModal() {
  try {
    gameMessageElement.textContent = "Loading move history...";
    
    const response = await fetch("http://localhost:3000/api/game/history");
    if (!response.ok) throw new Error("History request failed");
    
    const data = await response.json();
    console.log("History response:", data);
    
    populateHistoryList(data.history);
    rewindModalElement.classList.remove("hidden");
    regularUI.classList.add("hidden");
    gameMessageElement.textContent = "Select a move to rewind to";
  } catch (error) {
    console.error("Error loading history:", error);
    gameMessageElement.textContent = "Failed to load move history";
  }
}

/**
 * Populates the move history list in the rewind modal
 * @param {Array<Object>} history - Array of move history objects
 */
function populateMoveHistory(history) {
  const container = document.getElementById("move-history-items");
  container.innerHTML = "";
  
  console.log("History:", history);
  history.forEach((move, index) => {
    const item = document.createElement("div");
    item.className = "move-item";
    item.dataset.index = index;
    
    // Create move number display
    const moveNumber = document.createElement("div");
    moveNumber.className = "move-number";
    moveNumber.textContent = `Move ${index + 1}`;
    
    // Create move summary
    const moveSummary = document.createElement("div");
    moveSummary.className = "move-summary";
    moveSummary.textContent = getMoveSummary(move);
    
    // Add click handler to select move
    item.addEventListener("click", () => {
      document.querySelectorAll(".move-item").forEach(el => el.classList.remove("selected"));
      item.classList.add("selected");
      updateMoveDetails(history[index]);
    });
    
    // Assemble item
    item.appendChild(moveNumber);
    item.appendChild(moveSummary);
    container.appendChild(item);
  });
}

/**
 * Generates a summary string for a move
 * @param {Object} move - The move object
 * @returns {string} The move summary string
 */
function getMoveSummary(move) {
  const player = move.currentPlayer === "player1" ? "P1" : "P2";
  const action = move.lastAction === "cover" ? "covered" : "uncovered";
  const squares = move.lastSquares ? move.lastSquares.join(", ") : "none";
  return `${player} ${action} ${squares}`;
}

/**
 * Updates move details in the rewind modal
 * @param {Object} move - The move object to display details for
 */
function updateMoveDetails(move) {
  // Update basic move info
  document.getElementById("detail-player").textContent = 
    move.currentPlayer === "player1" ? "Player 1" : "Player 2";
  document.getElementById("detail-action").textContent = move.lastAction || "-";
  document.getElementById("detail-squares").textContent = 
    move.lastSquares ? move.lastSquares.join(", ") : "-";
  document.getElementById("detail-dice").textContent = 
    move.dice ? `${move.dice.dice1} + ${move.dice.dice2} = ${move.dice.total}` : "-";
  
  // Render board states
  renderMoveSquares("detail-player1-squares", 
                   move.player1.squares, 
                   move.advantage.player === "player1" ? move.advantage.square : -1);
  renderMoveSquares("detail-player2-squares", 
                   move.player2.squares, 
                   move.advantage.player === "player2" ? move.advantage.square : -1);
  
  // Update scores
  document.getElementById("detail-player1-score").textContent = move.player1.score;
  document.getElementById("detail-player2-score").textContent = move.player2.score;
}

/**
 * Renders squares for a move detail view
 * @param {string} elementId - The ID of the element to render squares in
 * @param {Array<number>} squares - Array of square values
 * @param {number} advantageSquare - The advantage square position (1-based index)
 */
function renderMoveSquares(elementId, squares, advantageSquare) {
  const container = document.getElementById(elementId);

  container.innerHTML = squares.map((square, index) => {
    const num = index + 1; 

    if (square === 0) {
      // Covered square
      return `<span class="covered${num === advantageSquare ? ' advantage' : ''}">0</span>`;
    } else {
      // Uncovered square
      return `<span${num === advantageSquare ? ' class="advantage"' : ''}>${square}</span>`;
    }
  }).join(" ");
}

/**
 * Checks if the advantage square can be uncovered
 * 
 * Determines if the current player is allowed to uncover
 * the opponent's advantage square
 * @returns {Promise<boolean>} Whether the advantage square can be uncovered
 */
async function canUncoverAdvantageSquare() {
  try {
    const response = await fetch('http://localhost:3000/api/game/can-uncover-advantage');
    if (response.ok) {
      const data = await response.json();
      return data.canUncover;
    }
    return true; // Default to allowing if check fails
  } catch (error) {
    console.error('Error checking advantage status:', error);
    return true;
  }
}