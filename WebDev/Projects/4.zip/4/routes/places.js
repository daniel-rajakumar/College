const express = require('express')
const router = express.Router();
const geo = require('node-geocoder');
const geocoder = geo({ provider: 'openstreetmap' });

router.get('/', async (req, res) => {
  const places = await req.db.findPlaces();
  res.json({ places })
})

router.put('/', async (req, res) => {
  const label = req.body.label;
  const address = req.body.address;

  const result = await geocoder.geocode("505 Ramapo Valley Road, Mahwah NJ");
  if (result.length > 0) {
      console.log(`The location of Ramapo is ${result[0].latitude}/${result[0].longitude}`)
  }

  const id = await req.db.createPlace(label, address);
  res.json({ id });
})

router.delete('/:id', async(req, res) => {
  await req.db.deletePlace(req.params.id)
  res.status(200).send();
})

module.exports = router